
const progress=document.getElementById('scrollProgress');
const toggle=document.querySelector('.nav-toggle');
const menu=document.querySelector('.nav__links');
function updateProgress(){const top=window.scrollY||document.documentElement.scrollTop;const max=document.documentElement.scrollHeight-document.documentElement.clientHeight;progress.style.width=`${max>0?Math.min(100,Math.max(0,top/max*100)):0}%`;}
window.addEventListener('scroll',updateProgress,{passive:true});window.addEventListener('resize',updateProgress);updateProgress();
if(toggle&&menu){toggle.addEventListener('click',()=>{const open=menu.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{menu.classList.remove('open');toggle.setAttribute('aria-expanded','false');}));}
const items=document.querySelectorAll('.reveal');const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if(reduced||!('IntersectionObserver'in window)){items.forEach(x=>x.classList.add('visible'));}else{const obs=new IntersectionObserver((entries,o)=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');o.unobserve(e.target);}}),{threshold:.12,rootMargin:'0px 0px -35px'});items.forEach(x=>obs.observe(x));}
const year=document.getElementById('year');if(year)year.textContent=new Date().getFullYear();
