# Content replacement checklist

- [ ] Add professional profile photograph.
- [ ] Confirm doctoral institution and start date.
- [ ] Confirm Ark Dental employment dates.
- [ ] Add verified Google Scholar, ORCID, and LinkedIn links.
- [ ] Add full publication citations and DOI links.
- [ ] Select 3-6 scientific figures with distribution permission.
- [ ] Select 2-4 video examples hosted externally.
- [ ] Add 2-4 documented GitHub repositories.
- [ ] Add verified analytics or outcomes to project case studies.
- [ ] Test all links on mobile and desktop.
