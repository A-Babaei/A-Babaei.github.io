# A. Babaei Professional Portfolio - GitHub Pages

This package contains a responsive multi-page portfolio and a rewritten public CV.

## Upload

Upload the **contents of this folder** to the root of `A-Babaei.github.io`:

- `index.html`
- `research.html`
- `projects.html`
- `code.html`
- `creative.html`
- `cv.html`
- `contact.html`
- `404.html`
- `assets/`
- `.nojekyll`
- `robots.txt`
- `sitemap.xml`

In GitHub: **Settings -> Pages -> Deploy from a branch -> main -> /(root)**.

## Add the real profile photo

1. Prepare a professional vertical 4:5 JPG or WebP, ideally at least 1000 x 1250 pixels.
2. Compress it to roughly 150-400 KB.
3. Upload it as `assets/images/profile-photo.jpg`.
4. In `index.html`, replace `assets/images/profile-photo-placeholder.svg` with `assets/images/profile-photo.jpg`.
5. Also update the `og:image` meta tag in every page, or use a separate social-preview image.

## Content requiring verification

Before final publication, confirm and replace:

- Doctoral institution and formal start date.
- Exact date range for Ark Dental / Andisheh Bayesteh Tejarat Co.
- Full publication citations, DOI links, authorship position, and status.
- Google Scholar, ORCID, and LinkedIn URLs.
- Any project performance metrics.

## Security and privacy

- Do not commit passwords, API keys, customer data, unpublished datasets, or confidential figures.
- Keep two-factor authentication enabled on GitHub.
- Use the public CV included here rather than the original CV containing a telephone number.
- Verify copyright before publishing article PDFs, client assets, or journal figures.
